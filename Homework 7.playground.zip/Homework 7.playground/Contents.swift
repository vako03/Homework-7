
import Foundation

//1.შექმენით Enum-ი სახელით WeekDay შესაბამისი ქეისებით. დაწერეთ ფუნქცია რომელიც იღებს ამ ენამის ტიპს და ბეჭდავს გადაწოდებული დღე სამუშაოა თუ დასვენების.


enum WeekDay {
    case ორშაბთი
    case სამშაბათი
    case ოთხშაბათი
    case ხუთშაბათი
    case პარასკევი
    case შაბათი
    case კვირა
}

func dayType(for day: WeekDay) -> String {
    switch day {
    case .შაბათი, .კვირა:
        return "დასვენებაა"
    default:
        return "სამუშაო დღეა"
    }
    
}
    
dayType(for: .ხუთშაბათი)
print(dayType(for: .შაბათი))


//2.შექმენით Enum-ი სახელად GialaSquad, რომელიც აღწერს გია სურამელაშვილის ფანკლუბის წევრების დონეებს ქეისებით : “TsigroviManto”, “MoshishvlebuliMkerdi”, “TuGapatio”. შექმენით ფროფერთი GialaSquad-ში, რომელსაც ექნება ინფორმაცია თუ რა ღირს თითოეული დონე თვეში (დონეები დალაგებულია ძვირიდან იაფისაკენ). დაუმატეთ მეთოდი რომელიც დაბეჭდავს თითოეული დონის ფასს

enum GialaSquad {
    case TsigroviManto
    case MoshishvlebuliMkerdi
    case TuGapatio

    var price: String {
        switch self {
        case .TsigroviManto:
            return "TsigroviManto: თვეში 49 ლარი"
        case .MoshishvlebuliMkerdi:
            return   "MoshishvlebuliMkerdi: თვეში 39 ლარი"
        case .TuGapatio:
            return "TuGapatio: თვეში 29 ლარი"
        }
    }
    
    static func printAllPrices() {
         for membership in [GialaSquad.TsigroviManto, .MoshishvlebuliMkerdi, .TuGapatio] {
             print(membership.price)
         }
     }


}

GialaSquad.printAllPrices()



//3.შექმენით enum-ი Weather შემდეგი ქეისებით, Sunny, Cloudy, Rainy და Snowy. ამ ქეისებს უნდა ჰქონდეს associated value Celsius-ის სახით. დაწერეთ function რომელიც მიიღებს ამ enum-ს, და მოგვცემს რეკომენდაციას რა უნდა ჩავიცვათ შესაბამისი ამინდის მიხედვით.

enum Weather {
    case sunny(Celsius:Int)
    case cloudy(Celsius:Int)
    case rainy(Celsius:Int)
    case snowy(Celsius:Int)
}

func weatherRecommendation(forTemperature temperature: Int) -> String {
    switch temperature {
    case let temp where temp > 25:
        return "\(temp)°C - მზიანი ამინდია, ჩაიცვი შორტები "
    case 18...25:
        return "\(temperature)°C - ღრუბლიანი ამინდია. ჩაიცვი ჟაკეტი"
    case 10...18:
        return "\(temperature)°C - წვიმიანი ამინდია. ჩაიცვი საწვიმარი"
    default:
        return "\(temperature)°C - თოვლიანი ამინდია. ჩაიცვი ჰუდი"
    }
}

print(weatherRecommendation(forTemperature: 26))
print(weatherRecommendation(forTemperature: 20))
print(weatherRecommendation(forTemperature: 10))
print(weatherRecommendation(forTemperature: 9))


//4.შექმენით struct-ი Kanye, ფროფერთებით: album, releaseYear. ამის შემდეგ შექმენით array-ი Kanye-ს ტიპის, ჩაამატეთ რამოდენიმე Kanye-ს ობიექტი, და შეავსეთ მასივი კანიეებით. დაწერეთ ფუნქცია, რომელიც მიიღებს ამ კანიეების მასივს და წელს. ფუნქციამ უნდა დაგვიბრუნოს ყველა ალბომი რომელიც გამოშვებულია გადაწოდებული წლის შემდეგ და დაბეჭდოს ისინი.

struct Kanye {
    var album: String
    var releaseYear: Int

    func albumsReleasedAfterYear(_ year: Int) -> [Kanye] {
        let filteredAlbums = kanyeArray.filter { $0.releaseYear > year }
        filteredAlbums.forEach { print($0.album) }
        return filteredAlbums
    }
}

var kanyeArray = [
    Kanye(album: "Donda", releaseYear: 2021),
    Kanye(album: "The Life of Pablo", releaseYear: 2016),
    Kanye(album: "Kids See Ghosts", releaseYear: 2018),
    Kanye(album: "Late Registration", releaseYear: 2005),
    Kanye(album: "Non-album single", releaseYear: 2015),
    Kanye(album: "Yeezus", releaseYear: 2013),
    Kanye(album: "Graduation", releaseYear: 2005),
    Kanye(album: "Ye", releaseYear: 2018),
    Kanye(album: "Jesus Is King", releaseYear: 2019)
]

let kanye = Kanye(album: "", releaseYear: 0)
let year = 2018
let albumsAfterYear = kanye.albumsReleasedAfterYear(year)
print(albumsAfterYear)


//5. შექმენით String-ის ტიპის lazy property wrapper სახელად, cachedData. ინიციალიზება გაუკეთეთ ქლოჟერით რომელიც აბრუნებს სტრინგს მნიშვნელობით “lazy ინიციალიზებულია”. მიწვდით ამ ფროფერთის და დაბეჭდეთ მისი მნიშვნელობა

import Foundation

@propertyWrapper
struct cachedData {
    private lazy var value: String = {
        return initializer()
    }()
    
    let initializer: () -> String
    
    var wrappedValue: String {
        mutating get {
            return value
        }
    }

    init(wrappedValue initializer: @escaping @autoclosure () -> String) {
        self.initializer = initializer
    }
}

struct Example {
    @cachedData var data: String
}

var example = Example(data: "lazy ინიციალიზებულია")
print(example.data)

// ეს ამოცანა  ის შემთხვევაა როცა 100%ით დასერჩილი ამბავია
